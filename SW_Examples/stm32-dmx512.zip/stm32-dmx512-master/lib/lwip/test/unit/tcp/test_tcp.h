#ifndef __TEST_TCP_H__
#define __TEST_TCP_H__

#include "../lwip_check.h"

Suite *tcp_suite(void);

#endif
